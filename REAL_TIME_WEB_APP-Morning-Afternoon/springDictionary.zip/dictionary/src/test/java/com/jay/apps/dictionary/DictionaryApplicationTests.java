package com.jay.apps.dictionary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DictionaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
